-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2022 at 01:26 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dormbase`
--

-- --------------------------------------------------------

--
-- Table structure for table `dorm`
--

CREATE TABLE `dorm` (
  `dormID` int(3) NOT NULL,
  `dormName` varchar(50) NOT NULL,
  `dormDescription` varchar(8192) NOT NULL,
  `dormShuttle` tinyint(1) DEFAULT NULL,
  `dormLaundry` tinyint(1) DEFAULT NULL,
  `dormCleaning` tinyint(1) DEFAULT NULL,
  `dormElectricity` tinyint(1) DEFAULT NULL,
  `dormLounge` tinyint(1) NOT NULL,
  `dormCommonKitchen` tinyint(1) NOT NULL,
  `dormParking` tinyint(1) NOT NULL,
  `dormGym` tinyint(1) NOT NULL,
  `dormPhone` varchar(15) DEFAULT NULL,
  `rulesetID` int(3) DEFAULT NULL,
  `regionID` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dorm`
--

INSERT INTO `dorm` (`dormID`, `dormName`, `dormDescription`, `dormShuttle`, `dormLaundry`, `dormCleaning`, `dormElectricity`, `dormLounge`, `dormCommonKitchen`, `dormParking`, `dormGym`, `dormPhone`, `rulesetID`, `regionID`) VALUES
(1, 'The Dorms', 'This project contains dorms for students who are willing to attend the LAU Jbeil campus. A place with a good student environment.', 0, 1, 1, 1, 0, 0, 1, 1, '03 640 657', 1, 2),
(2, 'Cronus', 'Our naturally lit rooms, contemporary furnishings, and sublime views provide a peaceful environment of study, rest, and innovation. This is truly the place to relax after a hectic learning atmosphere. Depending upon your wishes, you can choose between a Standard/Premium Room to a Junior/Cronus Suite. Each dormitory has different characteristics depending on your needs and/or preferences. This will be the place you can call: Home Away From Home. “Here, anything is possible”.', 1, 1, 1, 0, 1, 0, 1, 1, '09 543 217', 1, 3),
(3, 'Bahous Dorms', 'Our building is located right next to LAU Byblos. Medical Gate is the closest. Different room sizes are available, including single, double, or triple.', 0, 1, 1, 1, 1, 1, 1, 0, '81 592 000', 4, 4),
(5, 'Uniview', 'For students going off to university , their dorms become their home away from home.', 0, 1, 1, 0, 0, 0, 1, 0, '81 601 111', 3, 1),
(6, 'Maatouk Dorms', 'Fully furnished room+kitchenette\r\nPrivate bathroom\r\nElectricity/Generator\r\nFree internet 24/24\r\nDish cable\r\nAC/Heater\r\nLaundry\r\nBalcony\r\nRoom cleaning\r\nParking', 1, 0, 1, 1, 1, 0, 1, 0, '03 352 878', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `region`
--

CREATE TABLE `region` (
  `regionID` int(3) NOT NULL,
  `carTime` int(3) NOT NULL,
  `walkTime` int(3) NOT NULL,
  `distance` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `region`
--

INSERT INTO `region` (`regionID`, `carTime`, `walkTime`, `distance`) VALUES
(1, 1, 8, 600),
(2, 2, 12, 1000),
(3, 1, 2, 100),
(4, 3, 15, 1200);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `roomID` int(3) NOT NULL,
  `roomNumber` varchar(10) NOT NULL,
  `availability` tinyint(1) NOT NULL,
  `type` varchar(30) NOT NULL,
  `rent` decimal(5,2) NOT NULL,
  `description` varchar(8196) NOT NULL,
  `dormID` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`roomID`, `roomNumber`, `availability`, `type`, `rent`, `description`, `dormID`) VALUES
(2, 'B301', 1, 'Single', '155.00', 'A room designed for one person with a sea view. The room includes a kitchen, bathroom, dining table, study table, 2 closets, TV, couch, shelf, and a bed.', 1),
(3, 'B401', 1, 'Single', '155.00', 'A room designed for one person with a sea view. The room includes a kitchen, bathroom, dining table, study table, 2 closets, TV, couch, shelf, and a bed.', 1),
(4, '501', 1, 'Double', '400.00', 'A double room with an elevated view and a large balcony. The room is located under the roof.', 2),
(5, '31', 1, 'Single', '300.00', 'A room with a window and a sea view that overlooks the university.', 2),
(7, 'B304', 1, 'Double', '350.00', 'A large room accommodating 2 people with 2 balconies, 2 closets, and 2 beds. Comes with a kitchen and a bar customized for eating and a living room with 2 couches.', 1),
(8, 'B404', 1, 'Double', '350.00', 'A large room accommodating 2 people with 2 balconies, 2 closets, and 2 beds. Comes with a kitchen and a bar customized for eating and a living room with 2 couches.', 1),
(9, 'B201', 1, 'Single', '155.00', 'A room designed for one person with a sea view. The room includes a kitchen, bathroom, dining table, study table, 2 closets, TV, couch, shelf, and a bed.', 1),
(10, '11', 1, 'Suite', '500.00', 'A regular suite room in London building, the closest building to the LAU campus.', 2);

-- --------------------------------------------------------

--
-- Table structure for table `ruleset`
--

CREATE TABLE `ruleset` (
  `rulesetID` int(3) NOT NULL,
  `visitors` tinyint(1) NOT NULL,
  `pets` tinyint(1) DEFAULT NULL,
  `nonUni` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ruleset`
--

INSERT INTO `ruleset` (`rulesetID`, `visitors`, `pets`, `nonUni`) VALUES
(1, 1, 0, 0),
(2, 1, 0, 1),
(3, 0, 0, 0),
(4, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffID` int(3) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(70) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `dormID` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffID`, `username`, `password`, `email`, `phone`, `dormID`) VALUES
(1, 'maria.db', 'mariadb', 'mariadb@db.com', 'MariasNumber', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(3) NOT NULL,
  `studentID` varchar(9) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(80) NOT NULL,
  `phoneNum` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `studentID`, `username`, `password`, `email`, `phoneNum`) VALUES
(1, '202001193', 'karim.kichli', 'admin123', 'karim.kichli@lau.edu', '81 661 937'),
(2, '20200111', 'ali.zayat', 'ali123', 'ali.zayat@lau.edu', '81668932'),
(3, '20200222', 'mirvat.atwi', 'mirvat123', 'mirvat.atwi@lau.edu', '76123456'),
(4, '202001416', 'dany.chaddad', 'danyisthebest', 'dany.chaddad@lau.edu', '81615181'),
(13, '202000000', 'dohn.joe', 'dohnnythejohnny', 'dohn.joe@lau.edu', '81 111 111'),
(14, '201901234', 'john.smith', 'dontmiss', 'john.smith@lau.edu', '03 345 678'),
(15, '20180454', 'poe.doe', 'pohnny', 'poe.doe@lau.edu', '44 12 567');

-- --------------------------------------------------------

--
-- Table structure for table `user-books-room`
--

CREATE TABLE `user-books-room` (
  `userID` int(3) NOT NULL,
  `roomID` int(3) NOT NULL,
  `staffID` int(3) NOT NULL,
  `dateRental` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user-reviews-dorm`
--

CREATE TABLE `user-reviews-dorm` (
  `userID` int(3) NOT NULL,
  `dormID` int(3) NOT NULL,
  `dateSet` datetime NOT NULL DEFAULT current_timestamp(),
  `rating` decimal(2,1) NOT NULL,
  `reviewDescription` varchar(8196) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user-reviews-dorm`
--

INSERT INTO `user-reviews-dorm` (`userID`, `dormID`, `dateSet`, `rating`, `reviewDescription`) VALUES
(1, 1, '2022-12-17 23:06:37', '5.0', 'Great dorm, good prices and services. Staff members are very friendly and active. The rooms are spacious and the double room is one of the largest rooms in Byblos dorms.'),
(2, 1, '2022-12-19 02:14:30', '4.0', 'This dorm is great! It is exactly as promised. The services provided were as advertised. Staff are very friendly as well. The only reason it is not a 5 star is because of how far it is from the university.'),
(2, 2, '2022-12-19 02:17:49', '3.0', 'the dorms is better'),
(3, 1, '2022-12-19 02:14:30', '3.0', 'mid'),
(13, 1, '2022-12-19 02:16:57', '5.0', 'very rad. you should come'),
(14, 3, '2022-12-19 02:26:37', '2.0', 'Very bad services, runs out of water consistently, and is overpriced for the quality of its services.'),
(15, 3, '2022-12-19 02:26:37', '1.0', 'Run.');

-- --------------------------------------------------------

--
-- Table structure for table `utility`
--

CREATE TABLE `utility` (
  `utilityID` int(11) NOT NULL,
  `utilityName` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `regionID` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `utility`
--

INSERT INTO `utility` (`utilityID`, `utilityName`, `type`, `regionID`) VALUES
(1, 'Coffee Project', 'Cafe', 1),
(2, 'Youssef Market', 'Store', 2),
(3, 'F.R.I.E.N.D.S.', 'Store', 3),
(4, 'Olive Garden', 'Gym', 1),
(5, 'Rony Pharmacy', 'Pharmacy', 4),
(6, 'Angela Market', 'Store', 1),
(7, 'Latte Art', 'Cafe', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dorm`
--
ALTER TABLE `dorm`
  ADD PRIMARY KEY (`dormID`),
  ADD KEY `rulesetID` (`rulesetID`),
  ADD KEY `regionID` (`regionID`);

--
-- Indexes for table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`regionID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`roomID`),
  ADD KEY `dormID` (`dormID`);

--
-- Indexes for table `ruleset`
--
ALTER TABLE `ruleset`
  ADD PRIMARY KEY (`rulesetID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffID`),
  ADD KEY `dormID` (`dormID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `user-books-room`
--
ALTER TABLE `user-books-room`
  ADD PRIMARY KEY (`userID`,`roomID`,`staffID`,`dateRental`),
  ADD KEY `roomID` (`roomID`),
  ADD KEY `staffID` (`staffID`);

--
-- Indexes for table `user-reviews-dorm`
--
ALTER TABLE `user-reviews-dorm`
  ADD PRIMARY KEY (`userID`,`dormID`,`dateSet`),
  ADD KEY `dormID` (`dormID`);

--
-- Indexes for table `utility`
--
ALTER TABLE `utility`
  ADD PRIMARY KEY (`utilityID`),
  ADD KEY `regionID` (`regionID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dorm`
--
ALTER TABLE `dorm`
  MODIFY `dormID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `region`
--
ALTER TABLE `region`
  MODIFY `regionID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `roomID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ruleset`
--
ALTER TABLE `ruleset`
  MODIFY `rulesetID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staffID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `utility`
--
ALTER TABLE `utility`
  MODIFY `utilityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dorm`
--
ALTER TABLE `dorm`
  ADD CONSTRAINT `regionID` FOREIGN KEY (`regionID`) REFERENCES `region` (`regionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rulesetID` FOREIGN KEY (`rulesetID`) REFERENCES `ruleset` (`rulesetID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `dormID` FOREIGN KEY (`dormID`) REFERENCES `dorm` (`dormID`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`dormID`) REFERENCES `dorm` (`dormID`);

--
-- Constraints for table `user-books-room`
--
ALTER TABLE `user-books-room`
  ADD CONSTRAINT `user-books-room_ibfk_1` FOREIGN KEY (`roomID`) REFERENCES `room` (`roomID`),
  ADD CONSTRAINT `user-books-room_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`),
  ADD CONSTRAINT `user-books-room_ibfk_3` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffID`);

--
-- Constraints for table `user-reviews-dorm`
--
ALTER TABLE `user-reviews-dorm`
  ADD CONSTRAINT `user-reviews-dorm_ibfk_1` FOREIGN KEY (`dormID`) REFERENCES `dorm` (`dormID`),
  ADD CONSTRAINT `user-reviews-dorm_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`);

--
-- Constraints for table `utility`
--
ALTER TABLE `utility`
  ADD CONSTRAINT `utility_ibfk_1` FOREIGN KEY (`regionID`) REFERENCES `region` (`regionID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
