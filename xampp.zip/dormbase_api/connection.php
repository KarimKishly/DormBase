<?php
$serverHost = "localhost";
$user = "root";
$password = "";
$database = "dormbase";

$conn = new mysqli($serverHost, $user, $password, $database);

$action = $_POST["action"];

;
if($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
    return;
}

if("SELECT_ALL" == $action) {
    $table = $_POST["table"];
    $columns = $_POST["columns"];
    $db_data = array();
    $sql = "SELECT $columns FROM $table";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $db_data[] = $row;
        }
        echo json_encode($db_data);
    } else {
        echo "error";
    }
    $conn->close();
    return;
}
if("SELECT_SPECIFIC" == $action) {
    $table = $_POST["table"];
    $columns = $_POST["columns"];
    $condition = $_POST["condition"];
    $db_data = array();
    $sql = "SELECT $columns FROM $table WHERE $condition";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $db_data[] = $row;
        }
        echo json_encode($db_data);
    } else {
        echo "error";
    }
    $conn->close();
    return;
}
if("ADD_USER" == $action) {
    $studentID = $_POST["studentID"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $email = $_POST["email"];
    $phoneNum = $_POST["phoneNum"];
    $sql = "INSERT INTO user (userID, studentID, username, password, email, phoneNum)
    VALUES (null, '$studentID', '$username', '$password', '$email', '$phoneNum')";
    $result = $conn->query($sql);
    echo "success";
    $conn->close();
    return;
}
if("GET_REVIEWS" == $action) {
    $dormID = $_POST["dormID"];
    $db_data = array();
    $sql = "SELECT username, rating, reviewDescription FROM `user-reviews-dorm` NATURAL JOIN user WHERE dormID = $dormID";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $db_data[] = $row;
        }
        echo json_encode($db_data);
    } else {
        echo "error";
    }
    $conn->close();
    return;
}
if("BOOK_ROOM" == $action) {
    $roomID = $_POST["roomID"];
    $userID = $_POST["userID"];
    $sql1 = "INSERT INTO `user-books-room` (userID, roomID, staffID, dateRental)  VALUES($userID, $roomID, 1, DEFAULT)";
    $sql2 = "UPDATE room SET availability = '0' WHERE roomID = $roomID";
    if($conn->query($sql1) === TRUE) {
        echo "success";
    } else {
        echo "error";
    }
    if($conn->query($sql2) === TRUE) {
        echo "success";
    } else {
        echo "error";
    }
    $conn->close();
    return;
}
if("GET_RATING" == $action) {
    $dormID = $_POST["dormID"];
    $db_data = array();
    $sql = "SELECT AVG(rating) as rating FROM dorm NATURAL JOIN `user-reviews-dorm` WHERE dormID = $dormID GROUP BY dormID";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $db_data[] = $row;
        }
        echo json_encode($db_data);
    } else {
        echo "error";
    }
    $conn->close();
    return;
}
if("GET_ROOM_INFO" == $action) {
    $dormID = $_POST["dormID"];
    $db_data = array();
    $sql = "SELECT type from (dorm NATURAL JOIN room) JOIN `room-info` RI ON room.type=RI.type WHERE dormID = $dormID";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $db_data[] = $row;
        }
        echo json_encode($db_data);
    } else {
        echo "error";
    }
    $conn->close();
    return;
}
if("GET_BOOKINGS" == $action) {
    $userID = $_POST["userID"];
    $db_data = array();
    $sql = "SELECT dormName, roomNumber, rent, dateRental FROM dorm NATURAL JOIN room NATURAL JOIN `user-books-room` WHERE userID = $userID ORDER BY dateRental DESC";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $db_data[] = $row;
        }
        echo json_encode($db_data);
    } else {
        echo "error";
    }
    $conn->close();
    return;
}
if("GET_ALL" == $action) {
    $db_data = array();
    $sql = "SELECT * FROM $table ORDER BY dormID DESC";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $db_data[] = $row;
        }
        echo json_encode($db_data);
    } else {
        echo "error";
    }
    $conn->close();
    return;
}